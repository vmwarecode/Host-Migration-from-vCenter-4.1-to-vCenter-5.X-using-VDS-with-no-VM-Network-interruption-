cls
Write-Host "=====Staring SS to VDS migration====="
$VC55 = Read-Host "Enter vCenter 'Hostname or IP'"   
Write-Host "Connecting to vCenter: " $VC55 " ..."
Connect-VIServer -Server $VC55

$VMHost = Read-Host         "Enter 'Hostname or IP' for the ESXi that will be added to vCenter"
$DatacentersList = Get-Datacenter -Server $VC55 -Name *
Write-Host "Datacenters available:" $DatacentersList
$Datacenter = Read-Host "Enter 'Datacenter name' where ESXi will be connected to"
Write-Host "Adding ESXi host to the Virtual Center..."
Add-VMHost -Server $VC55 -Name $VMHost -Location $Datacenter -Confirm:$false -Force

$ClustersList = Get-Cluster -Server $VC55 -Location $Datacenter
Write-Host "Clusters available:" $ClustersList
$Cluster = Read-Host "Enter 'Cluster name' to move ESXi"

Move-VMHost $VMHost -Destination $Cluster -Server $VC55
$VMHostobj = Get-VMHost $VMHost
$stdSwitchesSrc = Get-VirtualSwitch -VMHost $VMHostobj -Standard

foreach($ss1 in $stdSwitchesSrc){
$stdSwitchesLeft = Get-VirtualSwitch -VMHost $VMHostobj -Standard
Write-Host "Standard Switches available" $stdSwitchesLeft
$ss2 = Read-Host "Select Standard Switch to migrate FROM " 
$ss = Get-VirtualSwitch -VMHost $VMHostobj -Standard -Name $ss2

	$vmlist =  Get-VirtualPortGroup -VirtualSwitch $ss | Get-VM
	if($vmlist -eq $null){
	Write-Host "*** This is VMkernel switch, starting migration***"
	Write-Host "ESXi SS to be migrated is : " $ss
	$pNicsList = Get-VMHostNetworkAdapter -Physical -VirtualSwitch $ss 
	$vmkNicsList = Get-VirtualPortGroup -VirtualSwitch $ss | Get-VMHostNetworkAdapter -VMKernel
		
	if($vmkNicsList -eq $null){
	Write-Host "There are no any VMkernel adapters found on " $ss
	} else {
			Write-Host "Host VMKernel adapters available on" $ss " are: " $vmkNicsList }
			
	if($pNicsList -eq $null){
	Write-Host "There are no any physical adapters connected to " $ss
	} else {
	Write-Host "Host physical adapters are: " $pNicsList }

	$VDSlist = Get-VDSwitch -Server $VC55
	Write-Host "vCenter: " $VC55 " available Distributed switches available are: " 
	Write-Host $VDSlist
	$vdsDest1 = Read-Host "Select 'vCenter Distributed switch' to migrate ESXi VMKernel networking TO" 
	$vdsDest = Get-VDSwitch -Server $VC55 -Name $vdsDest1
	$vdsPgList = Get-VDPortgroup -VDSwitch $vdsDest
	Write-Host "VDS portgroups are " $vdsPgList
	$pgDest = Read-Host "Select 'vCenter Distributed switch Port Group' to migrate ESXi VMKernel networking TO" 
	
	$pnicToMove1 = Read-Host "Select pnic to move to DVS"
	$pnicToMove = Get-VMHostNetworkAdapter -VMHost $VMHostobj -Physical -Name $pnicToMove1
	Add-VDSwitchVMHost -VDSwitch $vdsDest -VMHost $VMHost -Server $VC55
	Write-Host "Adding pnic to DVS " $vdsDest
	Add-VDSwitchPhysicalNetworkAdapter -DistributedSwitch $vdsDest -VMHostNetworkAdapter $pnicToMove -Confirm:$false
	
		
	$vmknicToMove1 = Read-Host "Select vmknic to move to DVS first"
	$vmknicToMove = Get-VMHostNetworkAdapter -VMHost $VMHostobj -VMKernel -Name $vmknicToMove1
	Set-VMHostNetworkAdapter -VirtualNic $vmknicToMove -PortGroup $pgDest -Confirm:$false
	Write-Host "Migrating the rest VMkernel nics to " $vdsDest
	Set-VMHostNetworkAdapter -VirtualNic $vmkNicsList -PortGroup $pgDest -Confirm:$false

	foreach($pNic in $pNicsList) {
		Add-VDSwitchPhysicalNetworkAdapter -DistributedSwitch $vdsDest -VMHostPhysicalNic $pNic -Confirm:$false
		Write-Host "Moving " $pNic " to " $vdsDest
}

	Write-Host "===Removing the VMkernel Standard Switch on ESXi==="
	Remove-VirtualSwitch -VirtualSwitch $ss -Confirm:$false
	
	} else {
	Write-Host "*** This is VM Network SS, starting VMNetwork migration***"
		Write-Host "ESXi SS that is going to be migrated is: " $ss 
		$VDSlistVM = Get-VDSwitch -Server $VC55
		Write-Host "vCenter: " $VC55 " available Distributed switches available are: " 
		Write-Host $VDSlistVM
		$VDSDEST1 = Read-Host "Select 'vCenter Distributed switch' to migrate VM Network TO" 
		$VDSDEST = Get-VDSwitch -Server $VC55 -Name $VDSDEST1
		Add-VDSwitchVMHost -VDSwitch $VDSDEST -VMHost $VMHost -Server $VC55
		$pNicsList = Get-VMHostNetworkAdapter -Physical -VirtualSwitch $ss
		Write-Host "Host physical adapters on " $ss " are: " $pNicsList
		$pnic = Read-Host "Enter ESXi physical adapter from Standard Switch:"$ss " to be migrated to DVS:" $VDSDEST " before VM Network migration, eg. vmnic<x>"
		$pnicToMove = Get-VMHostNetworkAdapter -VMHost $VMHostobj -Physical -Name $pnic
		Write-Host "Adding pnic to DVS " $VDSDEST
		Add-VDSwitchPhysicalNetworkAdapter -DistributedSwitch $VDSDEST -VMHostPhysicalNic $pnicToMove -Confirm:$false

		$vmlist =  Get-VirtualPortGroup -VirtualSwitch $ss | Get-VM
		if($vmlist -eq $null){
			Write-Host "There are no any VMs found on ESXi!"
		} else {
				foreach($vm in $vmlist){ 
					try { Write-Host "Migrating VM: " $vm "network adapters to Distributed Virtual Switch..."$VDSDEST
					Get-NetworkAdapter $vm | %{
					Write-Host "Migrating VM network adapter from port group" $_.NetworkName "for VM: " $vm
					$_ | Set-NetworkAdapter -Portgroup (Get-VDPortGroup -VDSwitch  $VDSDEST -Name $_.NetworkName) -Confirm:$false
					Write-Host "Network adapter from from port group " $_.NetworkName " for " $vm " has been migrated successfully."} }
					catch {
					Write-Host "VM Network migration failed. Check the networking of VM:" ""$vm""
					Exit
					}
				}
		}
		foreach($pNic in $pNicsList) {
		Add-VDSwitchPhysicalNetworkAdapter -DistributedSwitch $VDSDEST -VMHostPhysicalNic $pNic -Confirm:$false
		Write-Host "Moving " $pNic " to " $VDSDEST
		}
		Write-Host "Removing the Standard Switch from ESXi..."
		Remove-VirtualSwitch -VirtualSwitch $ss -Confirm:$false
		Write-Host "=====ESXi VMNetwork migration from " $ss " to " $VDSDEST "is done.====="
	}
Write-Host "=====ESXi network migration from VDS to SS is done.====="
}











